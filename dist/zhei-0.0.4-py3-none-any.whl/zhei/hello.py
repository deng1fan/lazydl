def hi():
    print("Hello, world!")
